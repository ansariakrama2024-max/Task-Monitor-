# Task Monitor (TM) Android app

## GitHub Actions APK build
The workflow is `.github/workflows/main.yml`. It runs on pushes to `main`/`master` and can be run manually:
1. GitHub repository -> **Actions**
2. **Task Monitor Android APK Build**
3. **Run workflow**
4. Open the run after it finishes and download **TaskMonitor-debug-apk** from Artifacts.

The workflow explicitly installs Android SDK 35 and builds with JDK 17 + Gradle 8.9.

## Build locally
Run `gradle --no-daemon clean assembleDebug` from the project root with JDK 17 and Android SDK platform 35/build-tools 35.0.0 installed.

## Task reminders
Notifications are scheduled locally on the device. The reminder notification's email action opens the email app with task details filled in. Email sending requires the user to press Send; automatic sending requires a connected mail service/backend.
