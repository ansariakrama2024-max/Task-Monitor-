package com.taskmonitor.tm

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.util.concurrent.TimeUnit

object Reminders {
    const val CHANNEL = "task_monitor_reminders"

    fun createChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                CHANNEL, "Task reminders", NotificationManager.IMPORTANCE_HIGH
            )
            ctx.getSystemService(NotificationManager::class.java)
                .createNotificationChannel(channel)
        }
    }

    fun cancel(ctx: Context, taskId: Long) {
        WorkManager.getInstance(ctx).cancelAllWorkByTag("task_$taskId")
    }

    fun schedule(ctx: Context, task: TaskItem) {
        val workManager = WorkManager.getInstance(ctx)
        workManager.cancelAllWorkByTag("task_${task.id}")

        val today = LocalDate.now()
        val assignedDate = runCatching { LocalDate.parse(task.taskDate) }.getOrNull()
        val dueDate = runCatching { LocalDate.parse(task.dueDate) }.getOrNull()

        if (task.status != "Completed") {
            if (assignedDate != null) {
                val assignmentTime = if (assignedDate.isAfter(today)) {
                    assignedDate.atTime(9, 0)
                } else {
                    LocalDateTime.now().plusMinutes(1)
                }
                enqueue(ctx, task, "Task assignment reminder", assignmentTime, "assignment")
            }

            if (dueDate != null) {
                val dueTime = if (dueDate.isAfter(today)) {
                    dueDate.atTime(9, 0)
                } else {
                    LocalDateTime.now().plusMinutes(2)
                }
                val dueTitle = if (dueDate == today) "Task due today" else if (dueDate.isBefore(today)) {
                    "Task overdue reminder"
                } else {
                    "Task due reminder"
                }
                enqueue(ctx, task, dueTitle, dueTime, "due")
            }
        }
    }

    private fun enqueue(
        ctx: Context,
        task: TaskItem,
        title: String,
        at: LocalDateTime,
        kind: String
    ) {
        val delayMillis = maxOf(
            0L,
            at.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli() -
                System.currentTimeMillis()
        )
        val data = workDataOf(
            "id" to task.id,
            "title" to title,
            "project" to task.projectNumber,
            "projectName" to task.projectName,
            "description" to task.description,
            "assignee" to task.assignee,
            "email" to task.email,
            "due" to task.dueDate,\n            "taskDate" to task.taskDate,\n            "priority" to task.priority,
            "kind" to kind
        )
        val request = OneTimeWorkRequestBuilder<TaskReminderWorker>()
            .setInputData(data)
            .setInitialDelay(delayMillis, TimeUnit.MILLISECONDS)
            .addTag("task_${task.id}")
            .build()
        WorkManager.getInstance(ctx).enqueue(request)
    }
}

class TaskReminderWorker(ctx: Context, params: WorkerParameters) :
    Worker(ctx, params) {

    override fun doWork(): Result {
        Reminders.createChannel(applicationContext)

        val taskId = inputData.getLong("id", 0L)
        val email = inputData.getString("email").orEmpty().trim()
        val assignee = inputData.getString("assignee").orEmpty()
        val project = inputData.getString("project").orEmpty()
        val projectName = inputData.getString("projectName").orEmpty()
        val description = inputData.getString("description").orEmpty()
        val dueDate = inputData.getString("due").orEmpty()
        val title = inputData.getString("title") ?: "Task reminder"

        val emailIntent = Intent(
            Intent.ACTION_SENDTO,
            Uri.fromParts("mailto", email, null)
        ).apply {
            putExtra(Intent.EXTRA_SUBJECT, "Task Monitor | $project | $title")
            putExtra(
                Intent.EXTRA_TEXT,
                "Hello $assignee,\n\nTask reminder:\n" +
                    "Project: $project - $projectName\n" +
                    "Task: $description\nDue date: $dueDate\n\n" +
                    "Please update the task status.\n\nRegards,\nTask Monitor"
            )
        }

        val pendingIntent = PendingIntent.getActivity(
            applicationContext,
            taskId.toInt() * 2 + if (inputData.getString("kind") == "due") 101 else 100,
            emailIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(applicationContext, Reminders.CHANNEL)
            .setSmallIcon(R.drawable.tm_logo)
            .setContentTitle(title)
            .setContentText("$project · $description · Due $dueDate")
            .setStyle(
                NotificationCompat.BigTextStyle().bigText(
                    "Assigned to $assignee\nProject: $project - $projectName\n" +
                        "Task: $description\nDue: $dueDate\n" +
                        "Tap Email Reminder to prepare an email."
                )
            )
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .addAction(0, "Email Reminder", pendingIntent)
            .setAutoCancel(true)
            .build()

        applicationContext.getSystemService(NotificationManager::class.java)
            .notify(taskId.toInt() * 2 + if (inputData.getString("kind") == "due") 1 else 0, notification)

        return Result.success()
    }
}
