package com.taskmonitor.tm

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class TaskDb(context: Context): SQLiteOpenHelper(context, "taskmonitor.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE tasks(id INTEGER PRIMARY KEY AUTOINCREMENT, project_number TEXT, project_name TEXT, task_date TEXT, description TEXT, priority TEXT, assignee TEXT, email TEXT, due_date TEXT, status TEXT, completed_date TEXT)")
    db.execSQL("CREATE INDEX idx_project ON tasks(project_number)")
    db.execSQL("CREATE INDEX idx_status ON tasks(status)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun all(): List<TaskItem> {
        val out=mutableListOf<TaskItem>(); readableDatabase.rawQuery("SELECT * FROM tasks ORDER BY project_number, due_date",null).use { c ->
            while(c.moveToNext()) out.add(TaskItem(c.getLong(0),c.getString(1)?:"",c.getString(2)?:"",c.getString(3)?:"",c.getString(4)?:"",c.getString(5)?:"Normal",c.getString(6)?:"",c.getString(7)?:"",c.getString(8)?:"",c.getString(9)?:"Open",c.getString(10)?:""))
        };return out
    }
    fun insert(t:TaskItem):Long { val v=values(t);return writableDatabase.insert("tasks",null,v) }
    fun update(t:TaskItem) { writableDatabase.update("tasks",values(t),"id=?", arrayOf(t.id.toString())) }
    fun delete(id:Long){writableDatabase.delete("tasks","id=?", arrayOf(id.toString()))}
    private fun values(t:TaskItem)=ContentValues().apply { put("project_number",t.projectNumber);put("project_name",t.projectName);put("task_date",t.taskDate);put("description",t.description);put("priority",t.priority);put("assignee",t.assignee);put("email",t.email);put("due_date",t.dueDate);put("status",t.status);put("completed_date",t.completedDate) }
}
