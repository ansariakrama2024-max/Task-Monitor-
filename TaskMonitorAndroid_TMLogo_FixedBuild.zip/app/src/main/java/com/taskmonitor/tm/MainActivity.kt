package com.taskmonitor.tm

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.time.LocalDate

class MainActivity : ComponentActivity() {
    private lateinit var db: TaskDb

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = TaskDb(this)
        Reminders.createChannel(this)
        if (Build.VERSION.SDK_INT >= 33) {
            registerForActivityResult(ActivityResultContracts.RequestPermission()) {}.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent {
            TaskMonitorUI(
                db = db,
                onEmail = { task, subject, body -> composeEmail(task.email, subject, body) },
                onSchedule = { Reminders.schedule(this, it) },
                onCancelSchedule = { Reminders.cancel(this, it) }
            )
        }
    }

    private fun composeEmail(to: String, subject: String, body: String) {
        val intent = Intent(Intent.ACTION_SENDTO, Uri.fromParts("mailto", to.trim(), null)).apply {
            putExtra(Intent.EXTRA_SUBJECT, subject)
            putExtra(Intent.EXTRA_TEXT, body)
        }
        runCatching { startActivity(intent) }.onFailure {
            startActivity(Intent(Intent.ACTION_SEND).apply {
                type = "message/rfc822"
                putExtra(Intent.EXTRA_EMAIL, arrayOf(to))
                putExtra(Intent.EXTRA_SUBJECT, subject)
                putExtra(Intent.EXTRA_TEXT, body)
            })
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TaskMonitorUI(db: TaskDb, onEmail: (TaskItem, String, String) -> Unit, onSchedule: (TaskItem) -> Unit, onCancelSchedule: (Long) -> Unit) {
    var tasks by remember { mutableStateOf(db.all()) }
    var showAdd by remember { mutableStateOf(false) }
    var selectedProject by remember { mutableStateOf("All projects") }
    var search by remember { mutableStateOf("") }
    val projects = remember(tasks) { listOf("All projects") + tasks.map { it.projectNumber }.distinct().sorted() }
    val visible = tasks.filter {
        (selectedProject == "All projects" || it.projectNumber == selectedProject) &&
            (search.isBlank() || it.description.contains(search, true) || it.assignee.contains(search, true) || it.projectNumber.contains(search, true))
    }
    fun refresh() { tasks = db.all() }

    MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF087E78), secondary = Color(0xFF0B5C75), background = Color(0xFFF5F8FB), surface = Color.White)) {
        Scaffold(
            topBar = {
                TopAppBar(title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(36.dp).background(Color(0xFF087E78), RoundedCornerShape(8.dp)), contentAlignment = Alignment.Center) {
                            Text("TM", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text("Task Monitor", fontWeight = FontWeight.Bold)
                            Text("Project-wise task tracking", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                })
            },
            floatingActionButton = { FloatingActionButton(onClick = { showAdd = true }) { Text("+", style = MaterialTheme.typography.headlineLarge) } }
        ) { padding ->
            Column(Modifier.padding(padding).padding(12.dp).fillMaxSize()) {
                OutlinedTextField(search, { search = it }, label = { Text("Search task / assignee / project") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Project", fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.width(8.dp))
                    var expanded by remember { mutableStateOf(false) }
                    Box {
                        OutlinedButton(onClick = { expanded = true }) { Text(selectedProject) }
                        DropdownMenu(expanded, onDismissRequest = { expanded = false }) {
                            projects.forEach { project -> DropdownMenuItem(text = { Text(project) }, onClick = { selectedProject = project; expanded = false }) }
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text("${visible.size} tasks", fontWeight = FontWeight.Bold)
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(visible, key = { it.id }) { task ->
                        TaskCard(
                            task,
                            onComplete = {
                                val completed = task.copy(status = "Completed", completedDate = LocalDate.now().toString())
                                db.update(completed); onCancelSchedule(task.id); refresh()
                                val subject = "Task Completed | ${task.projectNumber} | ${task.description}"
                                val body = "Task completed.\n\nProject: ${task.projectNumber} - ${task.projectName}\nTask: ${task.description}\nAssigned to: ${task.assignee}\nCompleted date: ${completed.completedDate}\nPriority: ${task.priority}"
                                onEmail(completed, subject, body)
                            },
                            onReminder = {
                                val subject = "Task Reminder | ${task.projectNumber} | ${task.description}"
                                val body = "Task reminder\nProject: ${task.projectNumber}\nTask: ${task.description}\nAssigned to: ${task.assignee}\nDue date: ${task.dueDate}\nPriority: ${task.priority}"
                                onEmail(task, subject, body)
                            },
                            onDelete = { onCancelSchedule(task.id); db.delete(task.id); refresh() }
                        )
                    }
                }
            }
        }
        if (showAdd) AddTaskDialog(onCancel = { showAdd = false }, onSave = { task ->
            val id = db.insert(task)
            val saved = task.copy(id = id)
            onSchedule(saved); refresh(); showAdd = false
        })
    }
}

@Composable
fun TaskCard(task: TaskItem, onComplete: () -> Unit, onReminder: () -> Unit, onDelete: () -> Unit) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), elevation = CardDefaults.cardElevation(2.dp)) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(task.projectNumber, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFF087E78))
                Spacer(Modifier.weight(1f))
                Text(task.priority.uppercase(), fontWeight = FontWeight.Bold, color = when (task.priority) {
                    "High" -> Color(0xFFB3261E); "Low" -> Color(0xFF27704A); else -> Color(0xFF9A6700)
                })
            }
            Text(task.projectName, style = MaterialTheme.typography.labelMedium, color = Color.Gray)
            Spacer(Modifier.height(4.dp))
            Text(task.description, fontWeight = FontWeight.SemiBold)
            Text("Assigned: ${task.assignee}  •  ${task.taskDate}", style = MaterialTheme.typography.bodySmall)
            Text("Due: ${task.dueDate}  •  Status: ${task.status}", style = MaterialTheme.typography.bodySmall)
            if (task.status == "Completed") Text("Completed: ${task.completedDate}", style = MaterialTheme.typography.bodySmall, color = Color(0xFF087E78))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                if (task.status != "Completed") Button(onClick = onReminder) { Text("Email Reminder") }
                if (task.status != "Completed") Button(onClick = onComplete) { Text("Complete + Email") }
                TextButton(onClick = onDelete) { Text("Delete") }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddTaskDialog(onCancel: () -> Unit, onSave: (TaskItem) -> Unit) {
    var project by remember { mutableStateOf("") }
    var projectName by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    var description by remember { mutableStateOf("") }
    var priority by remember { mutableStateOf("Normal") }
    var person by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var due by remember { mutableStateOf(LocalDate.now().plusDays(7).toString()) }
    var priorityExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text("Create Task") },
        text = {
            Column(Modifier.heightIn(max = 560.dp).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                OutlinedTextField(project, { project = it }, label = { Text("Project Number *") }, singleLine = true)
                OutlinedTextField(projectName, { projectName = it }, label = { Text("Project Name") }, singleLine = true)
                OutlinedTextField(date, { date = it }, label = { Text("Task / Assign Date (YYYY-MM-DD)") }, singleLine = true)
                OutlinedTextField(description, { description = it }, label = { Text("Task Description *") }, minLines = 2)
                Box {
                    OutlinedButton(onClick = { priorityExpanded = true }, modifier = Modifier.fillMaxWidth()) { Text("Priority: $priority") }
                    DropdownMenu(priorityExpanded, onDismissRequest = { priorityExpanded = false }) {
                        listOf("High", "Normal", "Low").forEach { DropdownMenuItem(text = { Text(it) }, onClick = { priority = it; priorityExpanded = false }) }
                    }
                }
                OutlinedTextField(person, { person = it }, label = { Text("Assigned Person") }, singleLine = true)
                OutlinedTextField(email, { email = it }, label = { Text("Assigned Email ID") }, singleLine = true)
                OutlinedTextField(due, { due = it }, label = { Text("Due Date (YYYY-MM-DD)") }, singleLine = true)
                Text("Reminders are scheduled for assignment date and due date. Tap the reminder notification to initiate an email.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
            }
        },
        confirmButton = {
            Button(onClick = { if (project.isNotBlank() && description.isNotBlank()) onSave(TaskItem(projectNumber = project, projectName = projectName, taskDate = date, description = description, priority = priority, assignee = person, email = email, dueDate = due)) }, enabled = project.isNotBlank() && description.isNotBlank()) { Text("Save Task") }
        },
        dismissButton = { TextButton(onClick = onCancel) { Text("Cancel") } }
    )
}
