package com.taskmonitor.tm

data class TaskItem(
    val id: Long = 0,
    val projectNumber: String,
    val projectName: String = "",
    val taskDate: String,
    val description: String,
    val priority: String,
    val assignee: String,
    val email: String,
    val dueDate: String,
    val status: String = "Open",
    val completedDate: String = ""
)
